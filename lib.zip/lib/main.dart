import 'package:flutter/material.dart';
import 'package:newsapp/pages/news.dart';

void  main() {
  runApp(MaterialApp(
    home: NewsApp(),
    
  ));
}